"""Turns raw rows into what planners see: names instead of ids, sentences instead of codes."""
from __future__ import annotations

import re
import time
import uuid
from collections import defaultdict
from collections.abc import Callable
from datetime import date, datetime
from typing import Any, TypeVar

from .carbon import estimate_kg_co2e
from .config import Settings
from .demo_weather import with_demo_storm
from .markdown import CLEAR_DAYS, DEMO_ELASTICITY, ELASTICITY, suggest
from .readiness import label as readiness_label
from .readiness import score as readiness_score
from .readiness import storm_window_days
from .schemas import (
    AskResponse,
    AskTable,
    BacktestStorm,
    DayUnits,
    DecisionResult,
    InventoryItem,
    MarkdownSuggestion,
    Me,
    NextAction,
    Overview,
    ProductForecast,
    ProductRef,
    Ref,
    StoreForecast,
    StoreSummary,
    Transfer,
    WeatherAlert,
    WeatherDay,
)
from .sources.base import DataSource, Row

T = TypeVar("T")

KIND_LABEL = {"storm": "Storm", "heavy_rain": "Heavy rain", "heat": "Heat wave"}
SEVERITY = ["storm", "heavy_rain", "heat"]
CONDITION_LABEL = {**KIND_LABEL, "rain": "Rain", "clear": "Clear"}
STATUS = {"SHORTAGE": "RUNNING_LOW", "SURPLUS": "EXTRA", "BALANCED": "OK"}
# Planners never see these words, whatever a source returns.
BANNED = re.compile(r"\b(sql|delta|databricks|genie|mlflow|warehouse|sku|mape|wape|model|api)\b", re.I)


def weekday(d: date | None) -> str | None:
    return d.strftime("%A") if d else None


def join_names(names: list[str]) -> str:
    return names[0] if len(names) == 1 else ", ".join(names[:-1]) + " and " + names[-1]


def plural(n: int, one: str, many: str | None = None) -> str:
    return f"{n} {one if n == 1 else (many or one + 's')}"


def decision_message(action: str, changed: list[str], skipped: list[str]) -> str:
    verb = "approved" if action == "APPROVED" else "rejected"
    parts = []
    if changed:
        parts.append(f"{plural(len(changed), 'transfer')} {verb}.")
    if skipped:
        parts.append(f"{len(skipped)} {'was' if len(skipped) == 1 else 'were'} already handled by someone else.")
    return " ".join(parts) or "Nothing to change."


REJECT_REASONS = {"TRUCK_UNAVAILABLE": "no truck was free", "STORE_CLOSED": "the store was closed",
                  "ALREADY_COVERED": "the stock was already covered", "ROUTE_TOO_SLOW": "the route was too slow",
                  "OTHER": "another reason"}


class Service:
    def __init__(self, source: DataSource, settings: Settings) -> None:
        self.source, self.settings = source, settings
        self._cache: dict[str, tuple[float, Any]] = {}
        # Planner decisions on markdown suggestions. Kept in memory: they reset when the server restarts.
        self.markdown_decisions: dict[tuple[str, str], dict[str, Any]] = {}

    # ---- tiny in-memory cache for read-only data ----------------------------------------------
    def _cached(self, key: str, fn: Callable[[], T], ttl: float | None = None) -> T:
        hit = self._cache.get(key)
        if hit and hit[0] > time.monotonic():
            return hit[1]
        value = fn()
        self._cache[key] = (time.monotonic() + (self.settings.cache_seconds if ttl is None else ttl), value)
        return value

    def _directory(self) -> tuple[dict[str, Row], dict[str, Row]]:
        def load() -> tuple[dict[str, Row], dict[str, Row]]:
            return ({s["store_id"]: s for s in self.source.stores()}, {p["product_id"]: p for p in self.source.products()})
        return self._cached("directory", load, ttl=300)

    # ---- people ---------------------------------------------------------------------------
    def me(self, email: str) -> Me:
        row = self._cached(f"user:{email.lower()}", lambda: self.source.user(email), ttl=60)
        role = (row or {}).get("role") or self.settings.default_role
        # On a local copy the person running it is the operator: the dev identity can approve even when it is not in the account list.
        if not row and self.settings.allow_dev_identity and email.lower() == self.settings.dev_user_email.lower():
            role = "planner"
        name = (row or {}).get("display_name") or email.split("@")[0].replace(".", " ").title()
        label = self._cached("data_label", lambda: self.source.setting("data_label"), ttl=300)
        return Me(email=email, name=name, role=role, can_approve=role in ("planner", "admin"), data_label=label)

    # ---- transfers ------------------------------------------------------------------------
    def _transfer(self, r: Row) -> Transfer:
        stores, products = self._directory()
        p, src, dst = products[r["product_id"]], stores[r["source_store_id"]], stores[r["dest_store_id"]]
        qty = int(r["qty"])
        return Transfer(
            id=r["rec_id"],
            headline=f"Move {qty} {p['name_plural'] if qty != 1 else p['name']} from {src['name']} to {dst['name']}",
            product=ProductRef(id=p["product_id"], name=p["name"], name_plural=p["name_plural"]),
            from_store=Ref(id=src["store_id"], name=src["name"]), to_store=Ref(id=dst["store_id"], name=dst["name"]),
            qty=qty, urgency=r["urgency"], confidence=r["confidence_level"], reason=r["reason"],
            sales_protected_usd=round(float(r["sales_protected_usd"] or 0)), distance_miles=int(r["distance_miles"] or 0),
            co2_kg=estimate_kg_co2e(qty, int(r["distance_miles"] or 0)),
            runs_low_day=weekday(r.get("runs_low_date")), status=r["status"], created_at=r.get("created_at"),
            decided_by=r.get("decided_by"), decided_at=r.get("decided_at"), note=r.get("decision_note"),
        )

    def precedents(self, rec_id: str) -> list[dict[str, str]]:
        """What planners decided the last time this route was used for this product, in plain words."""
        t = self.transfer(rec_id)
        if t is None:
            return []
        out = []
        for r in self.source.precedents(t.from_store.id, t.to_store.id, t.product.id):
            when = r["decided_at"].strftime("%d %B") if r.get("decided_at") else "earlier"
            why = r.get("decision_note") or REJECT_REASONS.get(r.get("reason_code") or "", "")
            verb = "Approved" if r["status"] == "APPROVED" else "Rejected"
            out.append({"decision": verb, "decided_on": when, "reason": why or "no reason given"})
        return out

    def analysis_charts(self) -> dict[str, Any]:
        """Chart data for the Analysis page, from whichever source is chosen."""
        stores, _ = self._directory()
        demand: dict[str, float] = defaultdict(float)
        for sid in stores:
            for row in self.source.predictions(sid):
                demand[str(row["forecast_date"])[:10]] += float(row["predicted_units"] or 0)
        gaps = self.source.gaps(None, None)
        short: dict[str, int] = defaultdict(int)
        for g in gaps:
            if g["status"] == "SHORTAGE":
                short[stores[g["store_id"]]["name"]] += 1
        pending = self.source.transfers("PENDING", None)
        by_urgency: dict[str, dict[str, float]] = defaultdict(lambda: {"moves": 0, "protected_usd": 0.0})
        by_product: dict[str, float] = defaultdict(float)
        _, products = self._directory()
        for t in pending:
            by_urgency[t["urgency"]]["moves"] += 1
            by_urgency[t["urgency"]]["protected_usd"] += float(t["sales_protected_usd"] or 0)
            by_product[products[t["product_id"]]["name_plural"]] += float(t["sales_protected_usd"] or 0)
        return {
            "as_of": self._as_of().isoformat() if self._as_of() else None,
            "demand_by_day": [{"date": d, "units": round(u)} for d, u in sorted(demand.items())],
            "stock_available": round(sum(float(g["available"] or 0) for g in gaps)),
            "shortages_by_store": [{"store": s, "count": n} for s, n in sorted(short.items(), key=lambda x: -x[1])],
            "transfers_by_urgency": [{"urgency": u, "moves": int(v["moves"]), "protected_usd": round(v["protected_usd"], 2)}
                                     for u, v in sorted(by_urgency.items())],
            "protected_by_product": [{"product": p, "protected_usd": round(v, 2)}
                                     for p, v in sorted(by_product.items(), key=lambda x: -x[1])],
        }

    def impact_figures(self) -> dict[str, Any]:
        """Headline figures for the business impact page: protected sales, estimated profit, carbon, and decisions."""
        from .carbon import estimate_kg_co2e

        rows = self.source.transfers(None, None)
        live_moves = [r for r in rows if r["status"] in ("PENDING", "APPROVED")]
        protected = sum(float(r["sales_protected_usd"] or 0) for r in live_moves)
        miles = sum(float(r["distance_miles"] or 0) for r in live_moves)
        co2 = sum(estimate_kg_co2e(int(r["qty"]), int(r["distance_miles"] or 0)) for r in live_moves)
        return {
            "protected_usd": round(protected, 2), "miles": round(miles), "co2_kg": round(co2, 1),
            "moves": len(live_moves),
            "pending": sum(1 for r in rows if r["status"] == "PENDING"),
            "approved": sum(1 for r in rows if r["status"] == "APPROVED"),
            "rejected": sum(1 for r in rows if r["status"] == "REJECTED"),
            "as_of": self._as_of().isoformat() if self._as_of() else None,
        }

    def markdowns(self, weather: str = "live") -> list[MarkdownSuggestion]:
        def build() -> list[MarkdownSuggestion]:
            stores, products = self._directory()
            demo = weather == "demo"
            elasticity = DEMO_ELASTICITY if demo else ELASTICITY
            assumption = ("Demo: each 10% off lifts sales by 40%, to show a stronger response. Live assumption is 15%."
                          if demo else "Each 10% off lifts sales by 15%. Test this on a pilot.")
            out = []
            for g in self.source.gaps(None, "SURPLUS"):
                p, s = products[g["product_id"]], stores[g["store_id"]]
                price = float(p["unit_price"])
                plan = suggest(float(g["spare_units"] or 0), float(g["avg_daily"] or 0), price, elasticity)
                if plan is None:
                    continue
                spare = round(float(g["spare_units"]))
                note = (f"Mark {p['name_plural']} down {plan['discount_pct']}% to ${plan['new_price']:.2f} to sell about "
                        f"{plan['units_cleared']} of {spare} in {CLEAR_DAYS} days, "
                        f"about ${plan['extra_cash_usd']:,.0f} more than holding them.")
                out.append(MarkdownSuggestion(
                    store=Ref(id=s["store_id"], name=s["name"]),
                    product=ProductRef(id=p["product_id"], name=p["name"], name_plural=p["name_plural"]),
                    spare_units=spare, current_price=price, note=note, assumption=assumption, **plan))
            return sorted(out, key=lambda m: -m.extra_cash_usd)
        found = self._cached(f"markdowns:{weather}", build)
        return [self._with_decision(m) for m in found]

    def _with_decision(self, m: MarkdownSuggestion) -> MarkdownSuggestion:
        d = self.markdown_decisions.get((m.store.id, m.product.id))
        if not d:
            return m
        return m.model_copy(update={"decision": d["decision"], "decided_by": d["decided_by"], "decided_at": d["decided_at"]})

    def decide_markdown(self, store_id: str, product_id: str, decision: str, actor: str) -> MarkdownSuggestion | None:
        """Approve or reject a markdown suggestion. Nothing changes in the stores: this records the planner's decision."""
        match = next((m for m in self.markdowns("live") + self.markdowns("demo")
                      if m.store.id == store_id and m.product.id == product_id), None)
        if match is None:
            return None
        self.markdown_decisions[(store_id, product_id)] = {
            "decision": decision.lower(), "decided_by": actor, "decided_at": datetime.now().isoformat(timespec="seconds"),
        }
        return self._with_decision(match)

    def backtest(self) -> list[BacktestStorm]:
        return [BacktestStorm.model_validate(r) for r in self.source.backtest()]

    def transfers(self, status: str | None, urgency: str | None) -> list[Transfer]:
        return [self._transfer(r) for r in self.source.transfers(status, urgency)]

    def transfer(self, rec_id: str) -> Transfer | None:
        r = self.source.transfer(rec_id)
        return self._transfer(r) if r else None

    def history(self) -> list[Transfer]:
        return [self._transfer(r) for r in self.source.history()]

    def decide(self, action: str, ids: list[str], actor: str, note: str | None, reason_code: str | None = None) -> DecisionResult:
        unique = list(dict.fromkeys(ids))  # a double-click or repeated id changes nothing twice
        d = self.source.decide(action, unique, actor, note, request_id=uuid.uuid4().hex, reason_code=reason_code)
        self._cache.pop("overview:live", None)
        self._cache.pop("overview:demo", None)
        return DecisionResult(action=action, changed=d.changed, skipped=d.skipped,  # type: ignore[arg-type]
                              message=decision_message(action, d.changed, d.skipped))

    # ---- today ------------------------------------------------------------------------------
    def alerts(self, weather: str = "live") -> list[WeatherAlert]:
        stores, _ = self._directory()
        groups: dict[tuple[str, str], dict[str, Any]] = {}
        for w in self._weather(None, weather):
            if w["condition"] not in KIND_LABEL:
                continue
            region = stores[w["store_id"]]["region"]
            g = groups.setdefault((w["condition"], region), {"date": w["forecast_date"], "name": w.get("event_name"), "stores": {}})
            if w["forecast_date"] < g["date"]:
                g["date"], g["name"] = w["forecast_date"], w.get("event_name")
            g["stores"][stores[w["store_id"]]["name"]] = None
        out = [
            WeatherAlert(date=g["date"], weekday=weekday(g["date"]) or "", kind=kind,  # type: ignore[arg-type]
                         title=f"{g['name'] or KIND_LABEL[kind]} expected {weekday(g['date'])}",
                         detail=f"{join_names(list(g['stores']))} in {region}", stores=list(g["stores"]))
            for (kind, region), g in groups.items()
        ]
        return sorted(out, key=lambda a: (a.date, SEVERITY.index(a.kind)))[:4]

    def _weather(self, store_id: str | None, mode: str) -> list[Row]:
        rows = self.source.weather(store_id)
        if mode != "demo":
            return rows
        stores, _ = self._directory()
        return with_demo_storm(rows, {sid: s["region"] for sid, s in stores.items()})

    def overview(self, weather: str = "live") -> Overview:
        def build() -> Overview:
            pending = self.source.transfers("PENDING", None)
            urgent = [r for r in pending if r["urgency"] == "URGENT"]
            shortages = self.source.gaps(None, "SHORTAGE")
            alerts = self.alerts(weather)
            if urgent:
                protected = round(sum(float(r["sales_protected_usd"] or 0) for r in urgent), -2)
                action = NextAction(title=f"Review {plural(len(urgent), 'urgent transfer')}",
                                    detail=f"Moving this stock protects about ${protected:,.0f} in sales." if protected else
                                    "Stores are about to run low on stock.", button="Review transfers", path="/transfers")
            elif pending:
                action = NextAction(title=f"Review {plural(len(pending), 'transfer')}",
                                    detail="Nothing is urgent, but a few moves would keep shelves full.",
                                    button="Review transfers", path="/transfers")
            else:
                action = NextAction(title="You're all caught up", detail="No transfers need a decision right now.",
                                    button="See store forecasts", path="/stores")
            as_of = max((g["as_of_date"] for g in shortages), default=None) or self._as_of()
            return Overview(urgent_transfers=len(urgent), pending_transfers=len(pending),
                            stores_at_risk=len({g["store_id"] for g in shortages}), next_alert=alerts[0] if alerts else None,
                            alerts=alerts, next_action=action, as_of=as_of, weather_source=weather)
        return self._cached(f"overview:{weather}", build)

    def _as_of(self) -> date | None:
        gaps = self.source.gaps(None, None)
        return gaps[0]["as_of_date"] if gaps else None

    # ---- stores ------------------------------------------------------------------------------
    def stores(self, weather: str = "live") -> list[StoreSummary]:
        stores, _ = self._directory()
        low: dict[str, int] = defaultdict(int)
        for g in self.source.gaps(None, "SHORTAGE"):
            low[g["store_id"]] += 1
        cover: dict[str, list[float]] = defaultdict(list)
        for g in self.source.gaps(None, None):
            cover[g["store_id"]].append(g["days_of_cover"])
        forecast: dict[str, list[tuple[str, str]]] = defaultdict(list)
        for w in self._weather(None, weather):
            forecast[w["store_id"]].append((str(w["forecast_date"]), w["condition"]))
        safety = float(self.source.setting("safety_stock_days") or 2)
        out = []
        for s in sorted(stores.values(), key=lambda s: s["name"]):
            sid = s["store_id"]
            window = storm_window_days(forecast[sid])
            ready = readiness_score(cover[sid], window, safety)
            out.append(StoreSummary(id=sid, name=s["name"], city=s["city"], region=s["region"], running_low=low[sid],
                                    readiness=ready, readiness_label=readiness_label(ready), storm_days=window))
        return out

    def store_forecast(self, store_id: str, weather_mode: str = "live") -> StoreForecast | None:
        stores, products = self._directory()
        if store_id not in stores:
            return None
        summary = next(s for s in self.stores(weather_mode) if s.id == store_id)
        weather = self._weather(store_id, weather_mode)
        gaps = {g["product_id"]: g for g in self.source.gaps(store_id, None)}
        by_product: dict[str, list[Row]] = defaultdict(list)
        preds = self.source.predictions(store_id)
        for r in preds:
            by_product[r["product_id"]].append(r)

        out = []
        for pid, p in products.items():
            g = gaps.get(pid)
            if not g or pid not in by_product:
                continue
            status = STATUS[g["status"]]
            out.append(ProductForecast(
                product=ProductRef(id=pid, name=p["name"], name_plural=p["name_plural"]),
                days=[DayUnits(date=r["forecast_date"], weekday=weekday(r["forecast_date"]) or "", units=round(r["predicted_units"]))
                      for r in by_product[pid]],
                total_units=round(g["forecast_units"]), range_low=round(g["forecast_p10"]), range_high=round(g["forecast_p90"]),
                available=round(g["available"]), status=status,  # type: ignore[arg-type]
                runs_low_day=weekday(g["runs_low_date"]) if status == "RUNNING_LOW" else None,
                why=self._why(p, weather, status),
            ))
        out.sort(key=lambda f: (f.status != "RUNNING_LOW", f.status != "EXTRA", f.product.id))
        days = [
            WeatherDay(date=w["forecast_date"], weekday=weekday(w["forecast_date"]) or "", condition=w["condition"],
                       label=CONDITION_LABEL.get(w["condition"], w["condition"]), temp_max_f=round(w["temp_max_f"]),
                       wind_max_mph=round(w["wind_max_mph"]), rain_in=round(w["rain_in"], 1))
            for w in weather
        ]
        as_of = preds[0]["as_of_date"] if preds else None
        return StoreForecast(store=summary, weather=days, products=out, as_of=as_of, weather_source=weather_mode)

    @staticmethod
    def _why(product: Row, weather: list[Row], status: str) -> str:
        """The weather behind a product's week, in a sentence."""
        driver = product["weather_driver"]
        match = {"wind": ["storm"], "rain": ["storm", "heavy_rain"], "heat": ["heat"]}[driver]
        hits = [w for w in weather if w["condition"] in match]
        if hits:
            w = min(hits, key=lambda x: x["forecast_date"])
            day = weekday(w["forecast_date"])
            detail = {"wind": f"winds up to {round(max(h['wind_max_mph'] for h in hits))} mph",
                      "rain": f"about {max(h['rain_in'] for h in hits):.1f} in of rain",
                      "heat": f"highs near {round(max(h['temp_max_f'] for h in hits))}°F"}[driver]
            return f"{CONDITION_LABEL[w['condition']]} on {day}, with {detail}, is lifting demand for {product['name_plural']}."
        return "A normal week is expected here." if status != "EXTRA" else "More than enough for this week's expected sales."

    # ---- inventory -----------------------------------------------------------------------------
    def inventory(self, status: str | None) -> list[InventoryItem]:
        stores, products = self._directory()
        want = {"RUNNING_LOW": "SHORTAGE", "EXTRA": "SURPLUS"}.get(status or "")
        rows = [g for g in self.source.gaps(None, want) if g["status"] in ("SHORTAGE", "SURPLUS")]
        out = [
            InventoryItem(store=Ref(id=g["store_id"], name=stores[g["store_id"]]["name"]),
                          product=ProductRef(id=g["product_id"], name=products[g["product_id"]]["name"],
                                             name_plural=products[g["product_id"]]["name_plural"]),
                          status=STATUS[g["status"]], available=round(g["available"]),  # type: ignore[arg-type]
                          on_the_way=round(g["in_transit"] or 0),
                          days_of_cover=round(g["days_of_cover"], 1) if g["days_of_cover"] < 999 else None,
                          runs_low_day=weekday(g["runs_low_date"]), spare_units=round(g["spare_units"]))
            for g in rows
        ]
        return sorted(out, key=lambda i: (i.status != "RUNNING_LOW", i.store.name, i.product.name))

    # ---- ask -------------------------------------------------------------------------------------
    def ask(self, question: str) -> AskResponse:
        res = self.source.ask(question)
        answer = " ".join(res.answer.split())
        if res.answered:  # one plain sentence from the Ask space; our own fallback text is already short and kept whole
            answer = plain_sentence(answer, has_table=bool(res.rows))
            answer = "Here's what I found." if BANNED.search(answer) else answer
        table = None
        if res.columns and res.rows:
            table = AskTable(columns=[c.replace("_", " ").capitalize() for c in res.columns],
                             rows=[[_coerce(v) for v in row] for row in res.rows])
        return AskResponse(answered=res.answered, answer=answer, table=table)


def plain_sentence(text: str, has_table: bool, limit: int = 240) -> str:
    """Genie writes markdown and sometimes a list; planners get one clean sentence, with the detail in the table."""
    text = re.sub(r"[*`#_]{1,3}", "", text)
    text = " ".join(text.split())
    if has_table and re.search(r":\s+-\s", text):  # "Here are the totals: - a: 1 - b: 2" -> the lead-in only
        text = text.split(":", 1)[0] + "."
    sentence = re.split(r"(?<=[.!?])\s", text, maxsplit=1)[0]
    if len(sentence) > limit:
        sentence = sentence[:limit].rsplit(" ", 1)[0].rstrip(",;: ") + "..."
    return sentence


def _coerce(v: Any) -> str | int | float | None:
    """Genie returns every cell as text; show numbers as numbers."""
    if isinstance(v, str) and re.fullmatch(r"-?\d+", v):
        return int(v)
    if isinstance(v, str) and re.fullmatch(r"-?\d+\.\d+", v):
        return float(v)
    return v
