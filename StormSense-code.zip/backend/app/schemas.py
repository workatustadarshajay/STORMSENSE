"""The API contract. The frontend's TypeScript types are generated from these models."""
from __future__ import annotations

from datetime import date, datetime
from typing import Annotated, Literal

from pydantic import BaseModel, Field, StringConstraints

Role = Literal["viewer", "planner", "admin"]
Urgency = Literal["URGENT", "NORMAL"]
Confidence = Literal["High", "Medium", "Low"]
TransferStatus = Literal["PENDING", "APPROVED", "REJECTED"]
StockStatus = Literal["RUNNING_LOW", "EXTRA", "OK"]
AlertKind = Literal["storm", "heavy_rain", "heat"]

TransferId = Annotated[str, StringConstraints(pattern=r"^TR-[A-Z0-9]{10}$")]


class Me(BaseModel):
    email: str
    name: str
    role: Role
    can_approve: bool
    data_label: str | None = Field(None, description="Set to 'sample' while the app shows sample data")


class Ref(BaseModel):
    id: str
    name: str


class ProductRef(Ref):
    name_plural: str


class WeatherAlert(BaseModel):
    date: date
    weekday: str
    kind: AlertKind
    title: str
    detail: str
    stores: list[str]


class NextAction(BaseModel):
    title: str
    detail: str
    button: str
    path: str


class Overview(BaseModel):
    urgent_transfers: int
    pending_transfers: int
    stores_at_risk: int
    next_alert: WeatherAlert | None
    alerts: list[WeatherAlert]
    next_action: NextAction
    as_of: date | None
    weather_source: Literal["live", "demo"] = Field("live", description="demo means a demo storm is placed on the weather screens")


class Transfer(BaseModel):
    id: str
    headline: str
    product: ProductRef
    from_store: Ref
    to_store: Ref
    qty: int
    urgency: Urgency
    confidence: Confidence
    reason: str
    sales_protected_usd: float
    distance_miles: int
    co2_kg: float = Field(0, description="Estimated kg CO2e for the move. See carbon.py for the assumptions.")
    runs_low_day: str | None
    status: TransferStatus
    created_at: datetime | None
    decided_by: str | None = None
    decided_at: datetime | None = None
    note: str | None = None


class ApproveRequest(BaseModel):
    ids: list[TransferId] = Field(min_length=1, max_length=50)
    note: str | None = Field(None, max_length=280)


RejectReason = Literal["TRUCK_UNAVAILABLE", "STORE_CLOSED", "ALREADY_COVERED", "ROUTE_TOO_SLOW", "OTHER"]


class RejectRequest(BaseModel):
    ids: list[TransferId] = Field(min_length=1, max_length=50)
    reason: str = Field(min_length=3, max_length=280)
    reason_code: RejectReason | None = Field(None, description="Structured reason; the daily run learns from it")


class DecisionResult(BaseModel):
    action: Literal["APPROVED", "REJECTED"]
    changed: list[str]
    skipped: list[str]
    message: str


class StoreSummary(Ref):
    city: str
    region: str
    running_low: int
    readiness: int = Field(0, ge=0, le=100, description="Share of products with enough cover for the storm window, 0 to 100")
    readiness_label: str = Field("", description="Ready, Watch or At risk")
    storm_days: int = Field(0, ge=0, description="Forecast days with a storm or heavy rain")


class DayUnits(BaseModel):
    date: date
    weekday: str
    units: int


class WeatherDay(BaseModel):
    date: date
    weekday: str
    condition: str
    label: str
    temp_max_f: int
    wind_max_mph: int
    rain_in: float


class ProductForecast(BaseModel):
    product: ProductRef
    days: list[DayUnits]
    total_units: int
    range_low: int
    range_high: int
    available: int
    status: StockStatus
    runs_low_day: str | None
    why: str


class StoreForecast(BaseModel):
    store: StoreSummary
    weather: list[WeatherDay]
    products: list[ProductForecast]
    as_of: date | None
    weather_source: Literal["live", "demo"] = Field("live", description="demo means a demo storm is placed on this forecast's weather")


class InventoryItem(BaseModel):
    store: Ref
    product: ProductRef
    status: StockStatus
    available: int
    on_the_way: int
    days_of_cover: float | None
    runs_low_day: str | None
    spare_units: int


class AskRequest(BaseModel):
    question: str = Field(min_length=3, max_length=500)


class AskTable(BaseModel):
    columns: list[str]
    rows: list[list[str | int | float | None]]


class AskResponse(BaseModel):
    answered: bool
    answer: str
    table: AskTable | None = None


class MarkdownSuggestion(BaseModel):
    store: Ref
    product: ProductRef
    spare_units: int = Field(description="Stock the store will not need in the week ahead")
    current_price: float
    discount_pct: int = Field(ge=10, le=40, description="Suggested discount, 10 to 40 percent")
    new_price: float
    units_cleared: int = Field(description="Units expected to sell in the clearance window at this discount")
    clears_all: bool
    extra_cash_usd: float = Field(description="Cash expected over holding the stock at full price, an estimate")
    note: str
    assumption: str = Field(description="How the estimate was made, so it can be checked")
    decision: str = Field("pending", description="pending, approved or rejected by a planner")
    decided_by: str | None = None
    decided_at: str | None = None


class DemoAlertResult(BaseModel):
    started: bool
    message: str


class BacktestStorm(BaseModel):
    event_name: str
    start_date: date
    end_date: date
    stores: int
    lost_units: float = Field(description="Units sold beyond the stock on hand when the storm started")
    lost_usd: float
    protected_units: float = Field(description="Lost units a nearby store with spare stock could have covered")
    protected_usd: float
    share_protected: float = Field(ge=0, le=1, description="Protected sales as a share of lost sales")


class Health(BaseModel):
    status: Literal["ok", "starting", "unavailable"]
    mode: str
    warehouse: Literal["ready", "starting", "unavailable", "not_checked"]


class StormDeskRequest(BaseModel):
    goal: str = Field(min_length=3, max_length=500)


class DeskStep(BaseModel):
    what: str = Field(description="Plain-language description of what storm desk checked")
    result: str


class DebateTurn(BaseModel):
    agent: str = Field(description="Which role spoke: Forecaster, Risk checker or Summary writer")
    message: str


class StormDeskPlan(BaseModel):
    answered: bool
    plan: list[str] = Field(default_factory=list, description="The plan, one sentence per item")
    steps: list[DeskStep] = Field(default_factory=list, description="What storm desk checked, in order")
    debate: list[DebateTurn] = Field(default_factory=list, description="How the three roles arrived at the plan")
    transfers: list[Transfer] = Field(default_factory=list, description="Pending transfers the plan refers to")
    message: str | None = None


StormDeskPlan.model_rebuild()


class WhatIfRequest(BaseModel):
    strength: int = Field(ge=0, le=100, description="How strong the storm is, 0 to 100")
    start_day: int = Field(ge=0, le=6, description="0 means tomorrow")
    days: int = Field(ge=1, le=4, description="How many days the storm lasts")
    region: Literal["Florida", "Texas", "California"] | None = None


class WhatIfRow(BaseModel):
    store: str
    product: str
    normal_units: int
    storm_units: int
    on_hand: int
    extra_lost_usd: float


class PlanChange(BaseModel):
    as_of: str
    before_version: int
    before_time: str
    now_version: int
    now_time: str
    shortage_stores_before: int
    shortage_stores_now: int
    units_short_before: int
    units_short_now: int
    sentence: str


class WhatIfResult(BaseModel):
    answered: bool
    message: str | None = None
    window: str | None = None
    sentence: str | None = None
    normal_units: int = 0
    storm_units: int = 0
    extra_demand_units: int = 0
    extra_lost_usd: float = 0.0
    stock_to_move_units: int = 0
    rows: list[WhatIfRow] = Field(default_factory=list)
    plan_change: PlanChange | None = None


class DraftMove(BaseModel):
    id: str
    headline: str
    urgency: str
    qty: int
    sales_protected_usd: float
    distance_miles: int
    co2_kg: float
    reason: str


class StoreNote(BaseModel):
    store: str
    text: str


class StormDraft(BaseModel):
    id: str
    status: str = Field(description="draft until a planner decides, then decided")
    source: str
    storm: str
    weekday: str
    onset: date
    stores: list[str]
    moves: list[DraftMove]
    protected_usd: float
    co2_kg: float
    markdowns_open: int
    store_notes: list[StoreNote] = Field(description="Draft notes for store managers. Not sent: store email addresses are not set up.")
    created_at: str
    decided_by: str | None
    decided_at: str | None
    approved: int
    rejected: int


class DraftDecision(BaseModel):
    approve_ids: list[str] = Field(default_factory=list, description="The moves to approve. Every other move in the draft is rejected.")
    reason: str = Field("Not needed for this storm.", min_length=3, max_length=280)


class LoadMove(BaseModel):
    id: str
    product: str
    qty: int


class LoadRoute(BaseModel):
    from_store: str
    to_store: str
    miles: int
    units: int
    moves: list[LoadMove]
    trips_now: int
    trips_together: int
    saved_usd: float
    saved_kg: float


class Loads(BaseModel):
    routes: list[LoadRoute]
    trips_now: int
    trips_together: int
    saved_usd: float
    saved_kg: float
    cost_per_mile: float
    truck_units: int


class ImpactHeadline(BaseModel):
    protected_usd: float
    margin_usd: float
    trucking_usd: float
    net_usd: float
    co2_kg: float
    moves: int
    pending: int
    approved: int
    rejected: int


class ChangeSince(BaseModel):
    last_plan_at: str | None
    moves_then: int | None
    moves_now: int


class TimelineEvent(BaseModel):
    at: str
    kind: str
    actor: str
    detail: str


class Impact(BaseModel):
    source: str
    as_of: date | None
    headline: ImpactHeadline
    assumptions: list[str]
    changes: ChangeSince
    timeline: list[TimelineEvent]

