# End-to-end demo script (3:00)

Read this with the app open. The numbers on screen come from the sample data, and they can shift slightly when the sample dates roll forward. Always read what is on the screen, not the numbers in this script.

## Before you start (5 minutes before the talk)

1. **Stop any older server, then start the sample build.**
   - Run `make kill-ports`, then `make dev-sample`.
   - Use `make dev-sample`, not `make dev`. `make dev` uses the live workspace when `backend/.env` exists.
2. **Open two browser windows.**
   - Window A: `http://localhost:5173/` (the landing page).
   - Window B: `http://localhost:5173/transfers`. Keep this window on the Transfers screen. You will use it for the repeat-approval moment.
3. **Check the sample label.** Go to `/today` in window A. The header must show "Sample data".
4. **Do one rehearsal approval** on a different transfer, then restart `make dev-sample` so the demo starts clean.
5. **Keep the backups ready.** These screenshots are in `docs/screenshots/`:
   - `app-today-desktop.png`: the Today screen.
   - `app-transfers-approved.png`: after approval.
   - `app-store-forecast-desktop.png`: Store forecast.
   - `app-ask-idle-desktop.png`: Ask.
   - `app-history-desktop.png`: History.

## Timeline

| Clock | Step | Screen | Length |
|---|---|---|---|
| 0:00 | 1. Landing | `/` | 0:20 |
| 0:20 | 2. Today | `/today` | 0:30 |
| 0:50 | 3. Transfers: approve | `/transfers` | 0:50 |
| 1:40 | 4. Stores and Ask | `/stores`, then `/ask` | 0:45 |
| 2:25 | 5. History and the repeat approval | `/history`, then window B | 0:30 |
| 2:55 | 6. Hand back to the slides | Slide 20 | 0:05 |

---

## Step 1: Landing (0:00 to 0:20)

**Screen:** window A, `/`.

**Do:** scroll slowly, down about one screen. Let the 3D window and the animated transfers show. Scroll back up. Click **Open today's plan**.

**Say:** "This is the front door. It explains the idea in a few lines, and the planner app is one click away. I'll go straight in."

**Expect:** the storm scene and the headline "Move stock before the storm, not after."

**If it is slow:** click the **Open the planner** button in the navbar. It goes to the same place.

---

## Step 2: Today (0:20 to 0:50)

**Screen:** `/today`.

**Do:** point at the greeting, then the three numbers in the "Today at a glance" row.

**Say:** "This is the morning view. The greeting uses the planner's name. The first number is the urgent transfers this morning. The second is the stores running low. The third is the next weather alert, with the days it is expected. Everything on this screen is a planner's to-do list for today."

**Expect:**
- The greeting, with the name Ava.
- "urgent transfers" and "stores running low" with numbers above zero.
- A weather alert, such as a heat wave, with the days and the places it affects.

**Do:** point at the "Review transfers" button at the bottom. Click it.

**If the numbers are zero:** say "The sample data is quiet this morning, so here is what the screen does when there are urgent moves." Then click **Review transfers** anyway. It still goes to the Transfers page.

---

## Step 3: Transfers: approve two moves (0:50 to 1:40)

**Screen:** `/transfers`, window A.

**Do:**
1. Find the first urgent transfer. It reads like "Move 54 1000W generators from Jacksonville to Orlando".
2. Open it. Read its reason aloud. The reason says why it matters: the storm, what the store will sell, and what it has.
3. Select the first two urgent transfers.
4. At the bottom, click **Approve 2**.
5. In the dialog titled **Approve 2 transfers?**, click **Approve**.

**Say:** "This move is 54 generators, from Jacksonville to Orlando. The reason is in plain words: the storm on Sunday, how many Orlando will sell, and how many it has. Each move shows the sales it protects and how sure the forecast is. I'll select the first two and approve them."

**Expect:** a message: "2 transfers approved." The two moves leave the pending list.

**Say after the message:** "Approved. The system did the arithmetic. The planner made the decision, and the decision is recorded."

**If the dialog does not open:** press **Approve 2** again, or refresh the page and reselect the two moves.

---

## Step 4: Stores and Ask (1:40 to 2:25)

**Screen:** `/stores`, then `/ask`, window A.

**Do (Stores):**
1. Open **Store forecast**.
2. In the **Store** dropdown, choose **Orlando**. Its label shows how many products are running low.
3. Point at the bars for expected sales per day, and the chip that says when the product runs low.

**Say:** "This is the store view. Choose a store, and you see what it is likely to sell this week, day by day. The product that runs low is marked, with the day it runs out."

**Expect:** Orlando's 1000W generators, marked as running low on Thursday, with the bars for the week.

**Do (Ask):**
1. Click **Ask** in the sidebar.
2. Click the suggested question **Which stores will run out of generators this week?**, or type it into the box that says "Ask a question".

**Say:** "Ask is for questions in plain language. It answers in one sentence, with a small table. It cannot change anything."

**Expect:** one sentence, such as "2 stores will run low on 1000W generators this week, starting with Orlando on Thursday," and a table with the units short.

**If Ask is slow:** say "Ask runs a live query, so it can take a moment. Here is the answer from the screenshot," and show `app-ask-idle-desktop.png`.

---

## Step 5: History and the repeat approval (2:25 to 2:55)

**Screen:** `/history`, window A. Then window B.

**Do (History):**
1. Click **History** in the sidebar.
2. Point at the two approvals from Step 3. Each row shows the decision, who made it and when.

**Say:** "Every decision is recorded: what was decided, by whom, and when. That is the audit trail."

**Do (repeat approval, in window B):**
1. Switch to window B. It still shows the Transfers page from before you approved the moves in window A.
2. Select the same transfer you approved in Step 3.
3. Click **Approve 1**, then click **Approve** in the dialog.

**Say:** "Now another planner tries to approve the same move, from a screen that was open before. The system refuses it."

**Expect:** the message: "1 was already handled by someone else." Nothing changes.

**Say after the message:** "Double approval is harmless. The system checks the current state before it writes anything."

**If window B shows nothing to select:** the move was already approved in window A, which is the point. Say: "The move has already left the pending list, so the second planner sees it as handled." Then move on.

---

## Step 6: Hand back to the slides (2:55 to 3:00)

**Do:** switch to the deck, slide 20 (Thank you).

**Say:** "That's the whole loop: the morning view, a decision, the store and the question, and the record. Now the one-minute close."

**Then:** go straight into the 8th-minute conclusion from the script.

---

## If something fails

| Problem | What to do |
|---|---|
| The app does not load | Say "I'll show the screenshots," and open `app-today-desktop.png`. Walk through the same steps with the images. |
| The header does not show "Sample data" | You are on the live workspace. Stop the server with `make kill-ports`, then run `make dev-sample`. |
| No urgent transfers | Say "the sample data is quiet this morning." Go to Transfers and show one move from the list. |
| Approve gives an error | Refresh the page, reselect the moves and try once more. If it fails again, use `app-transfers-approved.png`. |
| Ask hangs | Show `app-ask-idle-desktop.png` and read the answer from the script. |
| Storm desk or what-if | Do not show them. They need the live workspace. |

## Words to say and words to avoid

- **Say:** "on the sample data", "the system proposes, the planner decides", "every decision is recorded".
- **Avoid:** "guaranteed", "the AI decides", "it buys stock", "live". The app is not live yet.


---

# Numbers for the demo and the presentation

Every app figure below is **sample data**. The real-world figures are from outside sources, and the savings are a model, not a measurement.

## 1. Numbers from the app (sample data)

### Storms and heat events (backtest, five past events)

| Event | Dates | Stores | Sales lost if nothing moved | Protected by moves | Share protected |
|---|---|---|---|---|---|
| Hurricane Marlow | 14-18 Sep 2026 | 4 | $171,310 | $2,658 | 1.6% |
| Severe Storm Delta | 17-19 Apr 2026 | 3 | $46,887 | $335 | 0.7% |
| Atmospheric River Kestrel | 9-12 Jan 2026 | 3 | $42,409 | $0 | 0.0% |
| Tropical Storm Ines | 24-26 Aug 2026 | 3 | $34,351 | $7,095 | 20.7% |
| Heat Dome Ridge | 6-10 Jul 2026 | 3 | $7,197 | $2,049 | 28.5% |
| **Total** | | | **$302,154** | **$12,137** | **4.0%** |

The protected figure is an **upper bound**: the backtest uses what really sold.

### Current plan (impact page)

| Item | Figure |
|---|---|
| Moves in the plan | 16 (14 pending, 2 approved, 1 rejected) |
| Urgent transfers | 7 |
| Stores at risk | 5 |
| Protected sales (gross revenue) | $50,180 |
| Margin on protected sales (30%) | $15,054 |
| Trucking (about $2.50 a mile, one trip a move) | $6,460 |
| **Net (margin less trucking)** | **$8,594** |
| CO₂ for the moves | 584 kg |

### Truck sharing (Option 1)

| Item | Figure |
|---|---|
| Trips now | 14 |
| Trips with shared trucks | 9 |
| Saving | about $2,000 across 7 routes |
| CO₂ saved | about 720 kg |
| Example: Jacksonville to Tampa (172 miles) | 4 trips become 2, saving $860 |

### Markdown example (Option 2)

| Item | Figure |
|---|---|
| Store and product | Los Angeles, 1000W generators |
| Spare units | 30 |
| Price now | $499.00 |
| Markdown (10%) | $449.10 |
| Estimated units sold in 14 days | 30 of 30 |
| Estimated extra cash vs holding | about $260 |
| Assumption | each 10% off lifts sales by 15% (test in a pilot) |

### Forecast accuracy (sample data)

| Model | Weighted error |
|---|---|
| Our forecaster | about 0.40 |
| Same as last week (baseline) | 0.67 |
| 28-day average (baseline) | 0.57 |

### Testing

| Suite | Result |
|---|---|
| Backend and data tests | 172 pass |
| Frontend tests | 57 pass |

## 2. Real-world numbers (outside sources)

Figures are from search summaries, not full reports. Check each one before it goes on a slide.

### Out-of-stock losses, US

| Year | Figure | Scope | Source |
|---|---|---|---|
| 2008 | $93 billion a year lost to out-of-stocks | Survey of 124 retailers, 85,000+ stores | [RetailWire, RIS/IHL](https://retailwire.com/discussion/out-of-stocks-cost-retailers-93-billion/) |
| 2022 | $349 billion, overstock and out-of-stock combined | US and Canada | IHL, reported 2023 (source not confirmed) |
| 2018 | About $300 billion in markdown costs, about 12% of non-grocery sales | US non-grocery, modelled | [Apparel News, citing Coresight and Celect](https://www.apparelnews.net/news/2019/feb/07/markdowns-cost-us-retailers-300-billion-2018/) |

### Out-of-stock losses, Europe

| Year | Figure | Source |
|---|---|---|
| 2022 | France: €851 million missed sales at a 4.4% out-of-stock rate. UK: about £1 billion at 4.0% | [ESM Magazine, NielsenIQ](https://www.esmmagazine.com/a-brands/supermarkets-count-cost-of-out-of-stock-cooking-oils-nielsen-iq-177163) |
| Undated, likely mid-2000s | About €4 billion a year for European fast-moving consumer goods | ECR Europe and SymphonyIRI (source not confirmed) |
| 2002 | 3.7% to 4% of sales lost to out-of-stocks, 661 outlets in 29 countries | Gruen, Corsten and Bharadwaj (source not confirmed) |

### Markdown benchmark

| Item | Figure | Source |
|---|---|---|
| APQC markdowns as a share of sales | 4.0% (sample of 73 companies; quartile not labelled) | [APQC](https://www.apqc.org/what-we-do/benchmarking/open-standards-benchmarking/measures/markdowns-percentage-retail-sales) |

### Weather and generators (examples, not totals)

- Hurricane Sandy (2012): a New Jersey dealer went from about 75 generators to none within days, with over 250 calls asking for more. [Powersports Business](https://powersportsbusiness.com/?p=16918)
- Hurricane Frances (2004): Florida stores ran out, and stock was moved in from other states. [NBC News](https://www.nbcnews.com/news/amp/wbna5934255)
- Home Depot says demand for generators, tarps, cleaning supplies and grills rises after a storm, so there is a second sales wave.

No national figure for weather-driven losses was found.

## 3. How much we can save (model)

**Formula:** gross profit saved = sales × lost-sales rate × weather-sensitive share × share recoverable by moving stock × protection rate × margin

**Assumptions (not sourced, to be replaced with the retailer's own data):**
- Lost-sales rate: 4% (a proxy from the out-of-stock rates above; out-of-stock rate and lost sales are not the same).
- Weather-sensitive share: 20%.
- Share recoverable by moving stock: 30%.
- Margin: 30%, as in the app.

**Per $1 billion of annual sales:**

| Protection rate | Sales recovered | Gross profit saved |
|---|---|---|
| 4% (our backtest, all storms, upper bound) | about $96,000 | about $29,000 |
| 10% (assumed middle case) | about $240,000 | about $72,000 |
| 28% (our heat-event case, upper bound) | about $672,000 | about $202,000 |

The protection rate is the number to test in a pilot. The 4% and 28% cases are upper bounds from sample data, so real results will likely be lower. The app's own running cost has not been measured, so it is not in these figures.

## 4. Caveats to say out loud

- Every app number is sample data.
- The protected sales are upper bounds.
- The margin is an assumption.
- The savings model uses assumed shares. Replace them with a retailer's own figures before quoting a result.
- The real-world figures come from search summaries and some have no confirmed source. Check them first.
